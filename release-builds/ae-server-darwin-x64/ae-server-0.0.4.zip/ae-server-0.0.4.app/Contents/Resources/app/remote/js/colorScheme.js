    var statusColor = [
        "#444",
        "#5DA014",
        "#ffcc00",
        "#DB3838"
    ];
    var statusTextColor = [
        "#ffcc00",
        "#444",
        "#444",
        "#ffcc00"
    ];
    var statusText = [
        "MAN",
        "AUTO",
        "TOUCH",
        "WRITE"
    ];
    
    var knobClasses = [
        "knobWhite",
        "knobRed",
        "knobGray"
    ];