// function for drawing gui

